//
//  PhotoAttachment.swift
//  carMaintanceApp
//
//  Created by Trevor Elliott on 28/10/2025.
//


import Foundation
import SwiftUI
import UIKit

struct PhotoAttachment: Identifiable, Hashable, Codable {
    let id: UUID
    let vehicleId: UUID
    let relatedRecordId: UUID?   // service record / major work this belongs to (optional)
    let timestamp: Date
    let caption: String
    let imageData: Data          // JPEG or HEIC data

    init(
        id: UUID = UUID(),
        vehicleId: UUID,
        relatedRecordId: UUID? = nil,
        timestamp: Date = Date(),
        caption: String = "",
        imageData: Data
    ) {
        self.id = id
        self.vehicleId = vehicleId
        self.relatedRecordId = relatedRecordId
        self.timestamp = timestamp
        self.caption = caption
        self.imageData = imageData
    }

    // helper to turn back into SwiftUI Image
    func uiImage() -> UIImage? {
        UIImage(data: imageData)
    }
}
