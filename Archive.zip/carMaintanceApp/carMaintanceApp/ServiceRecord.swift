//
//  ServiceRecord.swift
//  carMaintanceApp
//
//  Created by Trevor Elliott on 28/10/2025.
//


import Foundation

struct ServiceRecord: Identifiable, Hashable, Codable {
    let id: UUID
    let vehicleId: UUID
    
    var date: Date
    var odometerAtService: Int
    var serviceType: String       // "Basic Service", "Brakes", etc.
    var performedBy: String       // "Owner", "Mechanic: King Auto Helensvale"
    var tasksDone: [String]       // ["Engine oil + filter", "Fuel filter", ...]
    var cost: Double?
    var notes: String

    init(
        id: UUID = UUID(),
        vehicleId: UUID,
        date: Date = Date(),
        odometerAtService: Int = 0,
        serviceType: String = "Basic Service",
        performedBy: String = "Owner",
        tasksDone: [String] = [],
        cost: Double? = nil,
        notes: String = ""
    ) {
        self.id = id
        self.vehicleId = vehicleId
        self.date = date
        self.odometerAtService = odometerAtService
        self.serviceType = serviceType
        self.performedBy = performedBy
        self.tasksDone = tasksDone
        self.cost = cost
        self.notes = notes
    }
}
