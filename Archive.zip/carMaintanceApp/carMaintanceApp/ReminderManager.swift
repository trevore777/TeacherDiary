//
//  ReminderManager.swift
//  carMaintanceApp
//
//  Created by Trevor Elliott on 28/10/2025.
//


import Foundation
import UserNotifications

class ReminderManager {
    static let shared = ReminderManager()
    
    private init() {}
    
    func requestPermission() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { ok, err in
            if let err = err {
                print("Notification permission error:", err)
            } else {
                print("Notification permission granted:", ok)
            }
        }
    }
    
    // Fire a one-off reminder at a specific Date
    func scheduleNotification(title: String, body: String, when date: Date) {
        let content = UNMutableNotificationContent()
        content.title = title
        content.body = body
        
        // break date into components
        let comps = Calendar.current.dateComponents(
            [.year, .month, .day, .hour, .minute],
            from: date
        )
        
        let trigger = UNCalendarNotificationTrigger(dateMatching: comps, repeats: false)
        
        let request = UNNotificationRequest(
            identifier: UUID().uuidString,
            content: content,
            trigger: trigger
        )
        
        UNUserNotificationCenter.current().add(request) { err in
            if let err = err {
                print("Failed to schedule:", err)
            } else {
                print("Scheduled:", title, "for", date)
            }
        }
    }
}
