import SwiftUI

struct AddWorkView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject var store: GarageStore
    let vehicle: Vehicle
    
    @State private var title = ""
    @State private var date = Date()
    @State private var odo = ""
    @State private var who = "Workshop"
    @State private var cost = ""
    @State private var notes = ""
    
    // photos for this major work
    @State private var showCamera = false
    @State private var showLibrary = false
    @State private var tempImages: [UIImage] = []
    
    var body: some View {
        Form {
            Section("Work Summary") {
                TextField("Title (e.g. 'Rear diff rebuild')", text: $title)
                
                DatePicker("Date", selection: $date, displayedComponents: .date)
                
                TextField("Odometer (km)", text: $odo)
                    .keyboardType(.numberPad)
                
                TextField("Who did it", text: $who)
                
                TextField("Cost (optional)", text: $cost)
                    .keyboardType(.decimalPad)
            }
            
            Section("Notes / Parts") {
                TextField("Notes (parts replaced, brand, etc.)",
                          text: $notes,
                          axis: .vertical)
                .lineLimit(3...6)
            }
            
            Section("Photos") {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack {
                        ForEach(Array(tempImages.enumerated()), id: \.offset) { (_, img) in
                            Image(uiImage: img)
                                .resizable()
                                .scaledToFill()
                                .frame(width: 80, height: 80)
                                .clipped()
                                .cornerRadius(8)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 8)
                                        .stroke(.gray.opacity(0.4), lineWidth: 1)
                                )
                        }
                    }
                    .padding(.vertical, 4)
                }
                
                HStack {
                    Button {
                        showCamera = true
                    } label: {
                        Label("Take Photo", systemImage: "camera")
                    }
                    
                    Button {
                        showLibrary = true
                    } label: {
                        Label("Choose Photo", systemImage: "photo.on.rectangle")
                    }
                }
            }
        }
        .navigationTitle("Add Major Work")
        .toolbar {
            ToolbarItem(placement: .cancellationAction) {
                Button("Cancel") { dismiss() }
            }
            ToolbarItem(placement: .confirmationAction) {
                Button("Save") { saveWork() }
            }
        }
        .sheet(isPresented: $showCamera) {
            ImagePicker(sourceType: .camera) { img in
                tempImages.append(img)
            }
        }
        .sheet(isPresented: $showLibrary) {
            ImagePicker(sourceType: .photoLibrary) { img in
                tempImages.append(img)
            }
        }
    }
    
    private func saveWork() {
        let odoInt = Int(odo) ?? 0
        let costDouble = Double(cost)
        
        // 1. create the work item
        let job = MajorWork(
            vehicleId: vehicle.id,
            date: date,
            odometerAtWork: odoInt,
            title: title,
            workshopOrSelf: who,
            cost: costDouble,
            notes: notes
        )
        
        store.addWork(job)
        
        // 2. save photos for this job
        for img in tempImages {
            if let jpegData = img.jpegData(compressionQuality: 0.8) {
                let attachment = PhotoAttachment(
                    vehicleId: vehicle.id,
                    relatedRecordId: job.id,
                    timestamp: Date(),
                    caption: title,
                    imageData: jpegData
                )
                store.addPhoto(attachment)
            }
        }
        
        dismiss()
    }
}
