import SwiftUI

struct AddServiceView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject var store: GarageStore
    let vehicle: Vehicle
    
    @State private var date = Date()
    @State private var odo = ""
    @State private var serviceType = "Basic Service"
    @State private var performedBy = "Owner / DIY"
    @State private var cost = ""
    @State private var notes = ""
    
    // checklist toggles
    @State private var didOil = true
    @State private var didOilFilter = true
    @State private var didFuelFilter = false
    @State private var didWaterTrap = false
    @State private var didAirFilter = false
    @State private var didBrakes = false
    @State private var didGrease = false
    
    // photos for this service
    @State private var showCamera = false
    @State private var showLibrary = false
    @State private var tempImages: [UIImage] = []
    
    var body: some View {
        Form {
            Section("Basics") {
                DatePicker("Date", selection: $date, displayedComponents: .date)
                
                TextField("Odometer (km)", text: $odo)
                    .keyboardType(.numberPad)
                
                Picker("Service Type", selection: $serviceType) {
                    Text("Basic Service").tag("Basic Service")
                    Text("Brakes / Pads").tag("Brakes / Pads")
                    Text("Air Filter").tag("Air Filter")
                    Text("Fuel / Water Separator").tag("Fuel / Water Separator")
                    Text("Grease / Suspension").tag("Grease / Suspension")
                    Text("Other").tag("Other")
                }
                
                TextField("Performed by", text: $performedBy)
                
                TextField("Cost (optional)", text: $cost)
                    .keyboardType(.decimalPad)
            }
            
            Section("Tasks done") {
                Toggle("Engine oil change", isOn: $didOil)
                Toggle("Oil filter replaced", isOn: $didOilFilter)
                Toggle("Fuel / petrol filter replaced", isOn: $didFuelFilter)
                Toggle("Water catcher drained (diesel)", isOn: $didWaterTrap)
                Toggle("Air filter cleaned/replaced", isOn: $didAirFilter)
                Toggle("Brake pads/inspection", isOn: $didBrakes)
                Toggle("Greased suspension/uni joints/steering", isOn: $didGrease)
            }
            
            Section("Notes") {
                TextField("Notes (brand of oil, workshop name, etc.)",
                          text: $notes,
                          axis: .vertical)
                .lineLimit(3...6)
            }
            
            Section("Photos") {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack {
                        ForEach(Array(tempImages.enumerated()), id: \.offset) { (_, img) in
                            Image(uiImage: img)
                                .resizable()
                                .scaledToFill()
                                .frame(width: 80, height: 80)
                                .clipped()
                                .cornerRadius(8)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 8)
                                        .stroke(.gray.opacity(0.4), lineWidth: 1)
                                )
                        }
                    }
                    .padding(.vertical, 4)
                }
                
                HStack {
                    Button {
                        showCamera = true
                    } label: {
                        Label("Take Photo", systemImage: "camera")
                    }
                    
                    Button {
                        showLibrary = true
                    } label: {
                        Label("Choose Photo", systemImage: "photo.on.rectangle")
                    }
                }
            }
        }
        .navigationTitle("Add Service")
        .toolbar {
            ToolbarItem(placement: .cancellationAction) {
                Button("Cancel") { dismiss() }
            }
            ToolbarItem(placement: .confirmationAction) {
                Button("Save") { saveService() }
            }
        }
        .sheet(isPresented: $showCamera) {
            ImagePicker(sourceType: .camera) { img in
                tempImages.append(img)
            }
        }
        .sheet(isPresented: $showLibrary) {
            ImagePicker(sourceType: .photoLibrary) { img in
                tempImages.append(img)
            }
        }
    }
    
    private func saveService() {
        let odoInt = Int(odo) ?? 0
        let costDouble = Double(cost)
        
        var taskList: [String] = []
        if didOil { taskList.append("Engine oil change") }
        if didOilFilter { taskList.append("Oil filter replaced") }
        if didFuelFilter { taskList.append("Fuel/petrol filter replaced") }
        if didWaterTrap { taskList.append("Water catcher drained") }
        if didAirFilter { taskList.append("Air filter serviced") }
        if didBrakes { taskList.append("Brakes inspected/pads changed") }
        if didGrease { taskList.append("Greased suspension/steering") }
        
        // 1. create the service record
        let newRecord = ServiceRecord(
            vehicleId: vehicle.id,
            date: date,
            odometerAtService: odoInt,
            serviceType: serviceType,
            performedBy: performedBy,
            tasksDone: taskList,
            cost: costDouble,
            notes: notes
        )
        
        store.addService(newRecord)
        
        // 2. persist each captured photo into the store
        for img in tempImages {
            if let jpegData = img.jpegData(compressionQuality: 0.8) {
                let attachment = PhotoAttachment(
                    vehicleId: vehicle.id,
                    relatedRecordId: newRecord.id,
                    timestamp: Date(),
                    caption: serviceType,
                    imageData: jpegData
                )
                store.addPhoto(attachment)
            }
        }
        
        dismiss()
    }
}
