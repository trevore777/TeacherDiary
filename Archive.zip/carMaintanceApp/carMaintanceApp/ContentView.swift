import SwiftUI

struct ContentView: View {
    @StateObject private var store = GarageStore()
    @State private var showAddVehicle = false
    
    var body: some View {
        NavigationStack {
            List {
                ForEach(store.vehicles) { vehicle in
                    NavigationLink(value: vehicle) {
                        VStack(alignment: .leading) {
                            Text(vehicle.nickname)
                                .font(.headline)
                            Text("\(vehicle.year) \(vehicle.make) \(vehicle.model)")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                            Text("Odo: \(vehicle.odometer) km")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        .padding(.vertical, 4)
                    }
                }
            }
            .navigationTitle("My Vehicles")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        showAddVehicle = true
                    } label: {
                        Label("Add Vehicle", systemImage: "plus.circle.fill")
                    }
                }
            }
            .navigationDestination(for: Vehicle.self) { vehicle in
                VehicleDetailView(vehicle: vehicle)
                    .environmentObject(store)
            }
        }
        .sheet(isPresented: $showAddVehicle) {
            NavigationStack {
                AddVehicleView()
                    .environmentObject(store)
            }
        }
    }
}
