import Foundation

@MainActor
class GarageStore: ObservableObject {
    @Published var vehicles: [Vehicle]
    @Published var serviceHistory: [ServiceRecord]
    @Published var majorWork: [MajorWork]
    @Published var reminderRules: [ReminderRule]   // ⭐ NEW
    @Published var photos: [PhotoAttachment]

    
    init() {
        let cruiser = Vehicle(
            nickname: "79 Series",
            make: "Toyota",
            model: "LandCruiser 79 Series",
            year: "2021",
            engine: "4.5L V8 Turbo Diesel",
            rego: "188EO5",
            vin: "___",
            odometer: 200000,
            notes: "Track water separator drains, greasing front end"
        )
        
        let z3 = Vehicle(
            nickname: "BMW Z3",
            make: "BMW",
            model: "Z3 Roadster",
            year: "1996",
            engine: "1.9L Petrol I4",
            rego: "545bc9",
            vin: "0",
            odometer: 150000,
            notes: "Cooling system, A/C regas, soft top condition"
        )
        
        self.vehicles = [cruiser, z3]
        self.serviceHistory = []
        self.majorWork = []
        self.photos = []
        
        // ⭐ Example default reminder rules you’d typically care about:
        self.reminderRules = [
            // Oil change every 6 months or 10,000 km on Cruiser
            ReminderRule(
                vehicleId: cruiser.id,
                itemName: "Engine oil + filter",
                lastServiceDate: Date(),
                lastServiceOdo: cruiser.odometer,
                dueEveryMonths: 6,
                dueEveryKm: 10_000,
                notes: "Use correct diesel oil grade"
            ),
            // Grease front end every 5,000 km on Cruiser
            ReminderRule(
                vehicleId: cruiser.id,
                itemName: "Grease front end / uni joints / steering",
                lastServiceDate: Date(),
                lastServiceOdo: cruiser.odometer,
                dueEveryMonths: nil,
                dueEveryKm: 5_000,
                notes: "Check tie rod ends & swivel hubs"
            ),
            // Z3 cooling system check every 12 months
            ReminderRule(
                vehicleId: z3.id,
                itemName: "Cooling system inspection",
                lastServiceDate: Date(),
                lastServiceOdo: z3.odometer,
                dueEveryMonths: 12,
                dueEveryKm: nil,
                notes: "Hoses, radiator, expansion tank, thermostat housing"
            )
        ]
    }
    
    // MARK: - Helpers
    
    func addVehicle(_ vehicle: Vehicle) {
        vehicles.append(vehicle)
    }
    
    func services(for vehicle: Vehicle) -> [ServiceRecord] {
        serviceHistory
            .filter { $0.vehicleId == vehicle.id }
            .sorted { $0.date > $1.date }
    }
    
    func work(for vehicle: Vehicle) -> [MajorWork] {
        majorWork
            .filter { $0.vehicleId == vehicle.id }
            .sorted { $0.date > $1.date }
    }
    
    func reminders(for vehicle: Vehicle) -> [ReminderRule] {     // ⭐ NEW
        reminderRules
            .filter { $0.vehicleId == vehicle.id }
    }
    
    func addService(_ service: ServiceRecord) {
        serviceHistory.append(service)
        
        // ⭐ When we log a service, auto-update matching reminder items.
        // Example: if service.tasksDone includes "Engine oil change",
        // update that ReminderRule's lastServiceDate / lastServiceOdo.
        for task in service.tasksDone {
            if let idx = reminderRules.firstIndex(
                where: { $0.vehicleId == service.vehicleId && $0.itemName.localizedCaseInsensitiveContains(taskPrefix(for: task)) }
            ) {
                reminderRules[idx].lastServiceDate = service.date
                reminderRules[idx].lastServiceOdo = service.odometerAtService
            }
        }
    }
    
    func addWork(_ workItem: MajorWork) {
        majorWork.append(workItem)
    }
    
    func photos(for vehicle: Vehicle) -> [PhotoAttachment] {
        photos
            .filter { $0.vehicleId == vehicle.id }
            .sorted { $0.timestamp > $1.timestamp }
    }

    func addPhoto(_ photo: PhotoAttachment) {
        photos.append(photo)
    }

    
    // Small helper to map “Engine oil change” -> “engine oil”
    private func taskPrefix(for task: String) -> String {
        // You can get smarter here if you like
        return task
            .lowercased()
            .replacingOccurrences(of: "change", with: "")
            .replacingOccurrences(of: "replaced", with: "")
            .replacingOccurrences(of: "serviced", with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }
}
