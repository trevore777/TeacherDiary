import SwiftUI

@main
struct CarCareApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
