import SwiftUI

struct AddVehicleView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject var store: GarageStore
    
    @State private var nickname = ""
    @State private var make = ""
    @State private var model = ""
    @State private var year = ""
    @State private var engine = ""
    @State private var rego = ""
    @State private var vin = ""
    @State private var odometer = ""
    @State private var notes = ""
    
    var body: some View {
        Form {
            Section("Basic Info") {
                TextField("Nickname (e.g. 79 Series, Z3)", text: $nickname)
                TextField("Make (e.g. Toyota)", text: $make)
                TextField("Model (e.g. LandCruiser 79 Series)", text: $model)
                TextField("Year (e.g. 1996)", text: $year)
                    .keyboardType(.numberPad)
                TextField("Engine (e.g. 1.9L Petrol I4)", text: $engine)
            }
            
            Section("IDs") {
                TextField("Rego", text: $rego)
                TextField("VIN", text: $vin)
            }
            
            Section("Odometer / Notes") {
                TextField("Current Odometer (km)", text: $odometer)
                    .keyboardType(.numberPad)
                TextField("Notes (mods, issues, tyres, etc.)",
                          text: $notes,
                          axis: .vertical)
                .lineLimit(3...6)
            }
        }
        .navigationTitle("Add Vehicle")
        .toolbar {
            ToolbarItem(placement: .cancellationAction) {
                Button("Cancel") { dismiss() }
            }
            ToolbarItem(placement: .confirmationAction) {
                Button("Save") { saveVehicle() }
                    .disabled(nickname.isEmpty || make.isEmpty || model.isEmpty || year.isEmpty)
            }
        }
    }
    
    private func saveVehicle() {
        let odoInt = Int(odometer) ?? 0
        
        let newVehicle = Vehicle(
            nickname: nickname,
            make: make,
            model: model,
            year: year,
            engine: engine,
            rego: rego,
            vin: vin,
            odometer: odoInt,
            notes: notes
        )
        
        store.addVehicle(newVehicle)
        dismiss()
    }
}
