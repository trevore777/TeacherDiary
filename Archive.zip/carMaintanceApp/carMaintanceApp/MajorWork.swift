//
//  MajorWork.swift
//  carMaintanceApp
//
//  Created by Trevor Elliott on 28/10/2025.
//


import Foundation

struct MajorWork: Identifiable, Hashable, Codable {
    let id: UUID
    let vehicleId: UUID

    var date: Date
    var odometerAtWork: Int
    var title: String         // "Rear diff rebuild", "Clutch replacement"
    var workshopOrSelf: String
    var cost: Double?
    var notes: String

    init(
        id: UUID = UUID(),
        vehicleId: UUID,
        date: Date = Date(),
        odometerAtWork: Int = 0,
        title: String = "",
        workshopOrSelf: String = "Owner",
        cost: Double? = nil,
        notes: String = ""
    ) {
        self.id = id
        self.vehicleId = vehicleId
        self.date = date
        self.odometerAtWork = odometerAtWork
        self.title = title
        self.workshopOrSelf = workshopOrSelf
        self.cost = cost
        self.notes = notes
    }
}
