import Foundation

struct ReminderRule: Identifiable, Hashable, Codable {
    let id: UUID
    let vehicleId: UUID
    
    // What maintenance item are we tracking?
    var itemName: String          // e.g. "Engine oil + filter"
    
    // When it was last done:
    var lastServiceDate: Date     // the date you last did it
    var lastServiceOdo: Int       // the odo at that time
    
    // How often it should be done:
    var dueEveryMonths: Int?      // e.g. 6  (do it every 6 months)
    var dueEveryKm: Int?          // e.g. 10000 (do it every 10,000 km)
    
    // Extra notes / hints:
    var notes: String             // e.g. "Use 10W-40 full synth"

    init(
        id: UUID = UUID(),
        vehicleId: UUID,
        itemName: String,
        lastServiceDate: Date,
        lastServiceOdo: Int,
        dueEveryMonths: Int? = nil,
        dueEveryKm: Int? = nil,
        notes: String = ""
    ) {
        self.id = id
        self.vehicleId = vehicleId
        self.itemName = itemName
        self.lastServiceDate = lastServiceDate
        self.lastServiceOdo = lastServiceOdo
        self.dueEveryMonths = dueEveryMonths
        self.dueEveryKm = dueEveryKm
        self.notes = notes
    }
    
    // MARK: - Helpers the UI uses
    
    /// Calculate the calendar date when this item is next due
    func nextDueDate() -> Date? {
        guard let m = dueEveryMonths else { return nil }
        var comps = DateComponents()
        comps.month = m
        return Calendar.current.date(byAdding: comps, to: lastServiceDate)
    }
    
    /// Calculate the odometer reading when this item is next due
    func nextDueOdo() -> Int? {
        guard let km = dueEveryKm else { return nil }
        return lastServiceOdo + km
    }
    
    /// Check if we're overdue by time or km
    func isDue(currentDate: Date = Date(), currentOdo: Int) -> Bool {
        var dueByTime = false
        if let nextDate = nextDueDate() {
            if currentDate >= nextDate {
                dueByTime = true
            }
        }
        
        var dueByKm = false
        if let nextOdo = nextDueOdo() {
            if currentOdo >= nextOdo {
                dueByKm = true
            }
        }
        
        return dueByTime || dueByKm
    }
}
