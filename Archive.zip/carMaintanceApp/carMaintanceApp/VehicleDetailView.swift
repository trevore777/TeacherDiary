import SwiftUI

struct VehicleDetailView: View {
    @EnvironmentObject var store: GarageStore
    let vehicle: Vehicle
    
    @State private var showAddService = false
    @State private var showAddWork = false
    @State private var showShare = false
    
    var body: some View {
        List {
            // Vehicle Info
            Section("Vehicle Info") {
                Text("Make/Model: \(vehicle.make) \(vehicle.model)")
                Text("Year: \(vehicle.year)")
                Text("Engine: \(vehicle.engine)")
                
                if !vehicle.rego.isEmpty {
                    Text("Rego: \(vehicle.rego)")
                }
                
                if !vehicle.vin.isEmpty {
                    Text("VIN: \(vehicle.vin)")
                }
                
                Text("Odometer: \(vehicle.odometer) km")
                
                if !vehicle.notes.isEmpty {
                    Text("Notes: \(vehicle.notes)")
                }
            }
            
            // Service History
            Section("Service History") {
                let services = store.services(for: vehicle)
                
                if services.isEmpty {
                    Text("No services recorded yet.")
                        .foregroundStyle(.secondary)
                } else {
                    ForEach(services) { svc in
                        VStack(alignment: .leading, spacing: 4) {
                            Text(svc.serviceType)
                                .font(.headline)
                            
                            Text("\(dateString(svc.date)) • \(svc.odometerAtService) km")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                            
                            Text("By: \(svc.performedBy)")
                                .font(.caption)
                            
                            if !svc.tasksDone.isEmpty {
                                Text("Tasks: " + svc.tasksDone.joined(separator: ", "))
                                    .font(.caption)
                            }
                            
                            if let cost = svc.cost {
                                Text(String(format: "Cost: $%.2f", cost))
                                    .font(.caption2)
                            }
                            
                            if !svc.notes.isEmpty {
                                Text("Notes: \(svc.notes)")
                                    .font(.caption2)
                            }
                        }
                        .padding(.vertical, 4)
                    }
                }
            }
            
            // Major Work / Mods
            Section("Major Work / Mods") {
                let work = store.work(for: vehicle)
                
                if work.isEmpty {
                    Text("No major work recorded yet.")
                        .foregroundStyle(.secondary)
                } else {
                    ForEach(work) { job in
                        VStack(alignment: .leading, spacing: 4) {
                            Text(job.title)
                                .font(.headline)
                            
                            Text("\(dateString(job.date)) • \(job.odometerAtWork) km")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                            
                            Text("By: \(job.workshopOrSelf)")
                                .font(.caption)
                            
                            if let cost = job.cost {
                                Text(String(format: "Cost: $%.2f", cost))
                                    .font(.caption2)
                            }
                            
                            if !job.notes.isEmpty {
                                Text("Notes: \(job.notes)")
                                    .font(.caption2)
                            }
                        }
                        .padding(.vertical, 4)
                    }
                }
            }
            
            // Maintenance Reminders
            Section("Maintenance Reminders") {
                let rems = store.reminders(for: vehicle)
                
                if rems.isEmpty {
                    Text("No reminders set.")
                        .foregroundStyle(.secondary)
                } else {
                    ForEach(rems) { rule in
                        VStack(alignment: .leading, spacing: 4) {
                            Text(rule.itemName)
                                .font(.headline)
                            
                            if let nextDate = rule.nextDueDate() {
                                Text("Next by date: \(dateString(nextDate))")
                                    .font(.subheadline)
                                    .foregroundStyle(.secondary)
                            }
                            
                            if let nextOdo = rule.nextDueOdo() {
                                Text("Next by odo: \(nextOdo) km")
                                    .font(.subheadline)
                                    .foregroundStyle(.secondary)
                            }
                            
                            Text("Last done: \(dateString(rule.lastServiceDate)) @ \(rule.lastServiceOdo) km")
                                .font(.caption)
                            
                            if !rule.notes.isEmpty {
                                Text("Notes: \(rule.notes)")
                                    .font(.caption2)
                            }
                            
                            let dueNow = rule.isDue(
                                currentDate: Date(),
                                currentOdo: vehicle.odometer
                            )
                            if dueNow {
                                Text("⚠ DUE NOW")
                                    .font(.caption)
                                    .bold()
                                    .foregroundStyle(.red)
                            }
                        }
                        .padding(.vertical, 4)
                    }
                }
            }
            
            // Photo Gallery
            Section("Photo Gallery") {
                let imgs = store.photos(for: vehicle)
                
                if imgs.isEmpty {
                    Text("No photos yet.")
                        .foregroundStyle(.secondary)
                } else {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack {
                            ForEach(imgs) { photo in
                                if let ui = photo.uiImage() {
                                    VStack(alignment: .leading, spacing: 4) {
                                        Image(uiImage: ui)
                                            .resizable()
                                            .scaledToFill()
                                            .frame(width: 100, height: 100)
                                            .clipped()
                                            .cornerRadius(10)
                                            .overlay(
                                                RoundedRectangle(cornerRadius: 10)
                                                    .stroke(.gray.opacity(0.4), lineWidth: 1)
                                            )
                                        
                                        Text(photo.caption.isEmpty ? "Photo" : photo.caption)
                                            .font(.caption)
                                            .lineLimit(1)
                                        
                                        Text(dateString(photo.timestamp))
                                            .font(.caption2)
                                            .foregroundStyle(.secondary)
                                    }
                                    .frame(width: 110)
                                }
                            }
                        }
                        .padding(.vertical, 4)
                    }
                }
            }
        }
        .navigationTitle(vehicle.nickname)
        .toolbar {
            ToolbarItemGroup(placement: .bottomBar) {
                Button {
                    showAddService = true
                } label: {
                    Label("Add Service", systemImage: "wrench.and.screwdriver")
                }
                
                Button {
                    showAddWork = true
                } label: {
                    Label("Add Work", systemImage: "gearshape.2")
                }
                
                Button {
                    showShare = true
                } label: {
                    Label("Report", systemImage: "printer")
                }
            }
        }
        .sheet(isPresented: $showAddService) {
            NavigationStack {
                AddServiceView(vehicle: vehicle)
                    .environmentObject(store)
            }
        }
        .sheet(isPresented: $showAddWork) {
            NavigationStack {
                AddWorkView(vehicle: vehicle)
                    .environmentObject(store)
            }
        }
        .sheet(isPresented: $showShare) {
            let report = serviceReportText(
                vehicle: vehicle,
                services: store.services(for: vehicle),
                work: store.work(for: vehicle)
            )
            ShareSheet(items: [report])
        }
    }
    
    private func dateString(_ d: Date) -> String {
        let df = DateFormatter()
        df.dateStyle = .medium
        return df.string(from: d)
    }
    
    private func serviceReportText(
        vehicle: Vehicle,
        services: [ServiceRecord],
        work: [MajorWork]
    ) -> String {
        var lines: [String] = []
        
        lines.append("Vehicle Service Report")
        lines.append("----------------------")
        lines.append("Nickname: \(vehicle.nickname)")
        lines.append("Make/Model: \(vehicle.make) \(vehicle.model)")
        lines.append("Year: \(vehicle.year)")
        lines.append("Engine: \(vehicle.engine)")
        if !vehicle.rego.isEmpty { lines.append("Rego: \(vehicle.rego)") }
        if !vehicle.vin.isEmpty { lines.append("VIN: \(vehicle.vin)") }
        lines.append("Current Odometer: \(vehicle.odometer) km")
        lines.append("")
        
        lines.append("Service History:")
        if services.isEmpty {
            lines.append("  (no service records)")
        } else {
            for svc in services {
                let d = dateString(svc.date)
                lines.append("• \(d) @ \(svc.odometerAtService) km")
                lines.append("  Type: \(svc.serviceType)")
                lines.append("  Performed by: \(svc.performedBy)")
                
                if !svc.tasksDone.isEmpty {
                    lines.append("  Tasks: \(svc.tasksDone.joined(separator: ", "))")
                }
                
                if let cost = svc.cost {
                    lines.append(String(format: "  Cost: $%.2f", cost))
                }
                
                if !svc.notes.isEmpty {
                    lines.append("  Notes: \(svc.notes)")
                }
                
                lines.append("")
            }
        }
        lines.append("")
        
        lines.append("Major Work / Mods:")
        if work.isEmpty {
            lines.append("  (no major work recorded)")
        } else {
            for job in work {
                let d = dateString(job.date)
                lines.append("• \(d) @ \(job.odometerAtWork) km")
                lines.append("  Title: \(job.title)")
                lines.append("  By: \(job.workshopOrSelf)")
                
                if let cost = job.cost {
                    lines.append(String(format: "  Cost: $%.2f", cost))
                }
                
                if !job.notes.isEmpty {
                    lines.append("  Notes: \(job.notes)")
                }
                
                lines.append("")
            }
        }
        
        return lines.joined(separator: "\n")
    }
}
