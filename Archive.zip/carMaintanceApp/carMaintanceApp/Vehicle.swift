//
//  Vehicle.swift
//  carMaintanceApp
//
//  Created by Trevor Elliott on 28/10/2025.
//


import Foundation

struct Vehicle: Identifiable, Hashable, Codable {
    let id: UUID
    var nickname: String          // "79 Series", "Z3"
    var make: String              // "Toyota", "BMW"
    var model: String             // "LandCruiser 79 Series", "Z3 Roadster"
    var year: String              // "1996"
    var engine: String            // "1.9L Petrol I4", "4.5L V8 Turbo Diesel"
    var rego: String
    var vin: String
    var odometer: Int             // current km
    var notes: String             // mods, general notes

    init(
        id: UUID = UUID(),
        nickname: String,
        make: String,
        model: String,
        year: String,
        engine: String,
        rego: String = "",
        vin: String = "",
        odometer: Int = 0,
        notes: String = ""
    ) {
        self.id = id
        self.nickname = nickname
        self.make = make
        self.model = model
        self.year = year
        self.engine = engine
        self.rego = rego
        self.vin = vin
        self.odometer = odometer
        self.notes = notes
    }
}
