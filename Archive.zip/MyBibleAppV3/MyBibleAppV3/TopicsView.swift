//
//  TopicsView.swift
//  MyBibileApp
//
//  Created by Trevor Elliott on 30/10/2025.
//


import SwiftUI

struct TopicsView: View {
    @StateObject private var topicsVM = TopicsViewModel()
    @StateObject private var bibleVM = BibleViewModel()

    var body: some View {
        NavigationStack {
            List {
                ForEach(topicsVM.topics) { topic in
                    NavigationLink {
                        TopicDetailView(topic: topic)
                            .environmentObject(topicsVM)
                            .environmentObject(bibleVM)
                    } label: {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(topic.title)
                                .font(.headline)
                            Text(topic.summary)
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        .padding(.vertical, 4)
                    }
                }
            }
            .navigationTitle("Topics")
        }
    }
}

struct TopicDetailView: View {
    let topic: ChainTopic
    @EnvironmentObject var topicsVM: TopicsViewModel
    @EnvironmentObject var bibleVM: BibleViewModel

    var body: some View {
        List {
            Section(header: Text("Description")) {
                Text(topic.summary)
            }

            Section(header: Text("Verses")) {
                ForEach(topicsVM.versesForTopic(topic, bibleVM: bibleVM)) { verse in
                    NavigationLink {
                        VerseDetailView(verse: verse)
                    } label: {
                        VStack(alignment: .leading) {
                            Text("\(verse.book) \(verse.chapter):\(verse.verse)")
                                .font(.body)
                                .bold()
                            Text(verse.text)
                                .font(.caption)
                                .foregroundColor(.secondary)
                                .lineLimit(3)
                        }
                        .padding(.vertical, 4)
                    }
                }
            }

            if !topic.nextTopicIDs.isEmpty {
                Section(header: Text("Related Topics")) {
                    ForEach(topic.nextTopicIDs, id: \.self) { tID in
                        if let nextTopic = topicsVM.topics.first(where: { $0.id == tID }) {
                            Text(nextTopic.title)
                        }
                    }
                }
            }
        }
        .navigationTitle(topic.title)
    }
}

struct VerseDetailView: View {
    let verse: Verse

    var body: some View {
        List {
            Section(header: Text("\(verse.book) \(verse.chapter):\(verse.verse) (KJV)")) {
                Text(verse.text)
                    .font(.body)
                    .textSelection(.enabled)
            }
        }
        .navigationTitle("Verse")
        .navigationBarTitleDisplayMode(.inline)
    }
}
