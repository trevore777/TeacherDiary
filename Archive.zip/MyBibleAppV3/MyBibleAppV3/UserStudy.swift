//
//  UserStudy.swift
//  MyBibileApp
//
//  Created by Trevor Elliott on 30/10/2025.
//


import Foundation

struct UserStudy: Identifiable, Codable, Hashable {
    let id: UUID
    var title: String           // "Men's Prayer Night 12 Nov"
    var verseIDs: [String]      // ["1Thess5:17", "Luke18:1"]
    var notes: String
}
