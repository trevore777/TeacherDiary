//
//  VerseStudySheet.swift
//  MyBibileApp
//
//  Created by Trevor Elliott on 30/10/2025.
//


import SwiftUI

struct VerseStudySheet: View {
    let verse: Verse

    // In a later version, inject view models.
    // For now we just read from MockData.

    // topics that include this verse
    var matchingTopics: [ChainTopic] {
        MockData.topics.filter { topic in
            topic.verseRefs.contains(verse.id)
        }
    }

    var body: some View {
        NavigationStack {
            List {
                Section(header: Text("Verse")) {
                    Text("\(verse.book) \(verse.chapter):\(verse.verse) (KJV)")
                        .font(.headline)
                    Text(verse.text)
                        .font(.body)
                        .fixedSize(horizontal: false, vertical: true)
                        .textSelection(.enabled)
                }

                if !matchingTopics.isEmpty {
                    Section(header: Text("Topics / Chains")) {
                        ForEach(matchingTopics) { topic in
                            NavigationLink {
                                TopicDetailView(topic: topic)
                            } label: {
                                VStack(alignment: .leading) {
                                    Text(topic.title)
                                        .font(.body)
                                        .bold()
                                    Text(topic.summary)
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                }
                            }
                        }
                    }
                }

                Section(header: Text("My Notes")) {
                    Text("Add your personal note here (future feature).")
                        .foregroundColor(.secondary)
                        .font(.caption)
                }
            }
            .navigationTitle("Study")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}
