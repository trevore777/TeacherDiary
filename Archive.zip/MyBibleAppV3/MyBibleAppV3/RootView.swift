//
//  RootView.swift
//  MyBibileApp
//
//  Created by Trevor Elliott on 30/10/2025.
//


import SwiftUI

struct RootView: View {
    var body: some View {
        TabView {
            BibleView()
                .tabItem {
                    Label("Bible", systemImage: "book")
                }

            TopicsView()
                .tabItem {
                    Label("Topics", systemImage: "link")
                }

            StudiesView()
                .tabItem {
                    Label("Studies", systemImage: "pencil.and.list.clipboard")
                }
        }
    }
}
