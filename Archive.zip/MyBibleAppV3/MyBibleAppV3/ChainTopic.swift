//
//  ChainTopic.swift
//  MyBibileApp
//
//  Created by Trevor Elliott on 30/10/2025.
//


import Foundation

struct ChainTopic: Identifiable, Codable, Hashable {
    let id: Int                 // e.g. 1001
    let title: String           // e.g. "Salvation"
    let summary: String         // short description
    let verseRefs: [String]     // ["John3:16", "Rom10:9", ...]
    let nextTopicIDs: [Int]     // for "continue chain" style jumps
}
