//
//  TopicsViewModel.swift
//  MyBibileApp
//
//  Created by Trevor Elliott on 30/10/2025.
//


import Foundation
import SwiftUI

@MainActor
class TopicsViewModel: ObservableObject {
    @Published var topics: [ChainTopic] = []

    init() {
        topics = MockData.topics.sorted { $0.title < $1.title }
    }

    func versesForTopic(_ topic: ChainTopic, bibleVM: BibleViewModel) -> [Verse] {
        topic.verseRefs.compactMap { ref in
            bibleVM.verse(by: ref)
        }
    }
}
