//
//  MockData.swift
//  MyBibileApp
//
//  Created by Trevor Elliott on 30/10/2025.
//


import Foundation

enum MockData {

    // Minimal KJV sample to prove navigation works
    static let verses: [Verse] = [
        Verse(
            id: "John3:16",
            book: "John",
            chapter: 3,
            verse: 16,
            text: "For God so loved the world, that he gave his only begotten Son, " +
                  "that whosoever believeth in him should not perish, but have everlasting life."
        ),
        Verse(
            id: "John3:17",
            book: "John",
            chapter: 3,
            verse: 17,
            text: "For God sent not his Son into the world to condemn the world; " +
                  "but that the world through him might be saved."
        ),
        Verse(
            id: "1Thess5:17",
            book: "1 Thessalonians",
            chapter: 5,
            verse: 17,
            text: "Pray without ceasing."
        ),
        Verse(
            id: "1Thess5:18",
            book: "1 Thessalonians",
            chapter: 5,
            verse: 18,
            text: "In every thing give thanks: for this is the will of God in Christ Jesus concerning you."
        )
    ]

    // A couple of Thompson-style topical chains
    static let topics: [ChainTopic] = [
        ChainTopic(
            id: 1001,
            title: "Salvation",
            summary: "God's plan to save us through Christ.",
            verseRefs: ["John3:16", "John3:17"],
            nextTopicIDs: [] // could later point to 'Grace', 'Faith', etc.
        ),
        ChainTopic(
            id: 2001,
            title: "Prayer",
            summary: "Continual prayer and thanksgiving.",
            verseRefs: ["1Thess5:17", "1Thess5:18"],
            nextTopicIDs: []
        )
    ]

    // Starter studies (user-created, in future this will be saved, not hard-coded)
    static let studies: [UserStudy] = [
        UserStudy(
            id: UUID(),
            title: "Men's Meeting: Thanksgiving",
            verseIDs: ["1Thess5:18", "1Thess5:17"],
            notes: "Talk about giving thanks even in trials."
        )
    ]
}
