//
//  UserNote.swift
//  MyBibileApp
//
//  Created by Trevor Elliott on 30/10/2025.
//


import Foundation

struct UserNote: Identifiable, Codable, Hashable {
    let id: UUID
    let verseID: String         // "John3:16"
    var content: String
    let dateCreated: Date
}
