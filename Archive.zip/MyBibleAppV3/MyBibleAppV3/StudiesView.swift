//
//  StudiesView.swift
//  MyBibileApp
//
//  Created by Trevor Elliott on 30/10/2025.
//


import SwiftUI

struct StudiesView: View {
    @StateObject private var studiesVM = StudiesViewModel()
    @StateObject private var bibleVM = BibleViewModel()

    var body: some View {
        NavigationStack {
            List {
                ForEach(studiesVM.studies) { study in
                    NavigationLink {
                        StudyDetailView(study: study, bibleVM: bibleVM)
                    } label: {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(study.title)
                                .font(.headline)
                            Text("\(study.verseIDs.count) verses")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        .padding(.vertical, 4)
                    }
                }
            }
            .navigationTitle("My Studies")
            .toolbar {
                Button {
                    // future: create new study
                } label: {
                    Image(systemName: "plus")
                }
            }
        }
    }
}

struct StudyDetailView: View {
    let study: UserStudy
    let bibleVM: BibleViewModel

    var verses: [Verse] {
        study.verseIDs.compactMap { id in
            bibleVM.verse(by: id)
        }
    }

    var body: some View {
        List {
            Section(header: Text("Notes")) {
                Text(study.notes)
            }

            Section(header: Text("Verses")) {
                ForEach(verses) { verse in
                    VStack(alignment: .leading, spacing: 4) {
                        Text("\(verse.book) \(verse.chapter):\(verse.verse)")
                            .bold()
                        Text(verse.text)
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    .padding(.vertical, 4)
                }
            }
        }
        .navigationTitle(study.title)
    }
}
