//
//  BibleViewModel.swift
//  MyBibileApp
//
//  Created by Trevor Elliott on 30/10/2025.
//


import Foundation
import SwiftUI

@MainActor
class BibleViewModel: ObservableObject {
    @Published var allVerses: [Verse] = []
    @Published var selectedBook: String? = nil
    @Published var selectedChapter: Int? = nil

    // Later we’ll break this into [Book:[Chapter:[Verses]]],
    // but for now we just filter.
    init() {
        allVerses = MockData.verses
    }

    var books: [String] {
        Array(Set(allVerses.map { $0.book }))
            .sorted()
    }

    func chapters(in book: String) -> [Int] {
        Array(
            Set(
                allVerses.filter { $0.book == book }.map { $0.chapter }
            )
        ).sorted()
    }

    func verses(in book: String, chapter: Int) -> [Verse] {
        allVerses
            .filter { $0.book == book && $0.chapter == chapter }
            .sorted { $0.verse < $1.verse }
    }

    func verse(by id: String) -> Verse? {
        allVerses.first { $0.id == id }
    }
}
