import SwiftUI

@main
struct BibleAppApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
        }
    }
}
