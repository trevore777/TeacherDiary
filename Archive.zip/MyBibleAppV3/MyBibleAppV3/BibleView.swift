//
//  BibleView.swift
//  MyBibileApp
//
//  Created by Trevor Elliott on 30/10/2025.
//


import SwiftUI

struct BibleView: View {
    @StateObject private var vm = BibleViewModel()

    var body: some View {
        NavigationStack {
            List {
                ForEach(vm.books, id: \.self) { book in
                    NavigationLink(book) {
                        ChapterListView(book: book)
                            .environmentObject(vm)
                    }
                }
            }
            .navigationTitle("Bible (KJV)")
        }
    }
}

struct ChapterListView: View {
    let book: String
    @EnvironmentObject var vm: BibleViewModel

    var body: some View {
        List {
            ForEach(vm.chapters(in: book), id: \.self) { chapter in
                NavigationLink("Chapter \(chapter)") {
                    VerseListView(book: book, chapter: chapter)
                        .environmentObject(vm)
                }
            }
        }
        .navigationTitle(book)
    }
}

struct VerseListView: View {
    let book: String
    let chapter: Int
    @EnvironmentObject var vm: BibleViewModel

    @State private var selectedVerse: Verse?

    var body: some View {
        List {
            ForEach(vm.verses(in: book, chapter: chapter)) { verse in
                VStack(alignment: .leading, spacing: 4) {
                    Text("\(verse.verse). \(verse.text)")
                        .font(.body)
                        .lineSpacing(4)
                        .textSelection(.enabled)

                    Button {
                        selectedVerse = verse
                    } label: {
                        Text("Study ↗")
                            .font(.caption)
                            .foregroundColor(.blue)
                    }
                }
                .padding(.vertical, 4)
            }
        }
        .navigationTitle("\(book) \(chapter)")
        .sheet(item: $selectedVerse) { verse in
            VerseStudySheet(verse: verse)
        }
    }
}
