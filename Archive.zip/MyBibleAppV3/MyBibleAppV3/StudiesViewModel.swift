//
//  StudiesViewModel.swift
//  MyBibileApp
//
//  Created by Trevor Elliott on 30/10/2025.
//


import Foundation
import SwiftUI

@MainActor
class StudiesViewModel: ObservableObject {
    @Published var studies: [UserStudy] = []

    init() {
        studies = MockData.studies
    }
}
