//
//  Verse.swift
//  MyBibileApp
//
//  Created by Trevor Elliott on 30/10/2025.
//


import Foundation

struct Verse: Identifiable, Codable, Hashable {
    // id like "John3:16"
    let id: String
    let book: String
    let chapter: Int
    let verse: Int
    let text: String
}
