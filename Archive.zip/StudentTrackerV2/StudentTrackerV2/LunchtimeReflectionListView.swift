
import SwiftUI

struct LunchtimeReflectionListView: View {
    @State private var reflections: [LunchtimeReflection] = loadLunchtimeReflections()
    @State private var showingMail = false
    @State private var pdfData: Data?

    var body: some View {
        VStack {
            List(reflections) { reflection in
                VStack(alignment: .leading) {
                    Text(reflection.studentName).bold()
                    Text("Email: \(reflection.studentEmail)")
                    Text("Date: \(reflection.date.formatted())")
                    Text("Reasons: \(reflection.reasons.joined(separator: ", "))")
                    Text("Comments: \(reflection.comments)")
                }
            }

            Button("Export to PDF & Email") {
                pdfData = createLunchtimePDF(from: reflections)
                showingMail = true
            }
            .sheet(isPresented: $showingMail) {
                if let data = pdfData {
                    ShareSheet(activityItems: [data])
                }
            }
        }
        .navigationTitle("View Lunchtime Reflections")
    }
}
