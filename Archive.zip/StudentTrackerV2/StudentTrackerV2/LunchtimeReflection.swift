
import Foundation

struct LunchtimeReflection: Identifiable, Codable {
    let id = UUID()
    let studentName: String
    let studentEmail: String
    let date: Date
    let reasons: [String]
    let comments: String
}
