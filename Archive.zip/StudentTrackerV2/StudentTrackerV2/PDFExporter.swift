import Foundation
import PDFKit
import UIKit
import SwiftUI

func createPDF(from observations: [StudentObservation]) -> Data? {
    print("📄 Generating PDF for \(observations.count) records")

    guard !observations.isEmpty else {
        print("⚠️ No data to export")
        return nil
    }

    let pageWidth: CGFloat = 595.2  // A4 width in points
    let pageHeight: CGFloat = 841.8 // A4 height in points
    let margin: CGFloat = 20
    let lineHeight: CGFloat = 20

    let pageRect = CGRect(x: 0, y: 0, width: pageWidth, height: pageHeight)
    let format = UIGraphicsPDFRendererFormat()
    let renderer = UIGraphicsPDFRenderer(bounds: pageRect, format: format)

    let data = renderer.pdfData { context in
        context.beginPage()
        var y = margin

        for obs in observations {
            let lines = [
                "Name: \(obs.name)",
                "Class: \(obs.studentClass)",
                "Behaviour: \(obs.behaviour)",
                "Note: \(obs.note)",
                "Date: \(obs.date.formatted())"
            ]

            for line in lines {
                print("📝 Writing line: \(line)")
                if y + lineHeight > pageHeight - margin {
                    context.beginPage()
                    y = margin
                }

                let attrs: [NSAttributedString.Key: Any] = [
                    .font: UIFont.systemFont(ofSize: 12),
                    .paragraphStyle: NSParagraphStyle.default
                ]

                let drawRect = CGRect(x: margin, y: y, width: pageWidth - 2 * margin, height: lineHeight)
                line.draw(in: drawRect, withAttributes: attrs)

                y += lineHeight
            }

            y += lineHeight // add space after record
        }
    }

    return data
}