import SwiftUI

struct MainMenuView: View {
    var body: some View {
        NavigationView {
            ZStack {
                // Background Image
                Image("BackgroundImage")
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea()

                VStack(spacing: 20) {
                    Spacer()

                    NavigationLink(destination: StudentObservationView()) {
                        Text("New Student Observation")
                            .font(.headline)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.white.opacity(0.8))
                            .cornerRadius(10)
                            .padding(.horizontal)
                    }

                    NavigationLink(destination: RecordFilterView()) {
                        Text("View Observations")
                            .font(.headline)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.white.opacity(0.8))
                            .cornerRadius(10)
                            .padding(.horizontal)
                    }

                    NavigationLink(destination: BlueSlipView()) {
                        Text("New Blue Slip")
                            .font(.headline)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.white.opacity(0.8))
                            .cornerRadius(10)
                            .padding(.horizontal)
                    }

                    NavigationLink(destination: BlueSlipListView()) {
                        Text("View Blue Slips")
                            .font(.headline)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.white.opacity(0.8))
                            .cornerRadius(10)
                            .padding(.horizontal)
                    }

                    NavigationLink(destination: LunchtimeReflectionForm()) {
                        Text("New Lunchtime Reflection")
                            .font(.headline)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.white.opacity(0.8))
                            .cornerRadius(10)
                            .padding(.horizontal)
                    }

                    NavigationLink(destination: LunchtimeReflectionListView()) {
                        Text("View Lunchtime Reflections")
                            .font(.headline)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.white.opacity(0.8))
                            .cornerRadius(10)
                            .padding(.horizontal)
                    }

                    Spacer()
                }
            }
            .navigationTitle("Main Menu")
        }
    }
}
