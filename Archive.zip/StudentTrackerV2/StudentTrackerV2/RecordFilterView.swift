import SwiftUI

enum TimeFilter: String, CaseIterable, Identifiable {
    case all = "All"
    case day = "Day"
    case week = "Week"
    case month = "Month"
    case year = "Year"
    var id: String { self.rawValue }
}

struct RecordFilterView: View {
    @State private var filterType: TimeFilter = .all
    @State private var searchText = ""
    @State private var observations = loadObservations()

    @State private var pdfToShare: Data? = nil
    @State private var showingMailView = false

    var filteredObservations: [StudentObservation] {
        let calendar = Calendar.current
        let now = Date()
        let filteredByTime: [StudentObservation] = observations.filter { obs in
            switch filterType {
            case .all:
                return true
            case .day:
                return calendar.isDate(obs.date, inSameDayAs: now)
            case .week:
                return calendar.isDate(obs.date, equalTo: now, toGranularity: .weekOfYear)
            case .month:
                return calendar.isDate(obs.date, equalTo: now, toGranularity: .month)
            case .year:
                return calendar.isDate(obs.date, equalTo: now, toGranularity: .year)
            }
        }

        if searchText.isEmpty {
            return filteredByTime
        } else {
            return filteredByTime.filter {
                $0.name.localizedCaseInsensitiveContains(searchText) ||
                $0.studentClass.localizedCaseInsensitiveContains(searchText)
            }
        }
    }

    var body: some View {
        VStack {
            Picker("Filter", selection: $filterType) {
                ForEach(TimeFilter.allCases) { filter in
                    Text(filter.rawValue)
                }
            }
            .pickerStyle(.segmented)
            .padding()

            TextField("Search by student or class", text: $searchText)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding(.horizontal)

            if filteredObservations.isEmpty {
                Text("No records found.")
                    .foregroundColor(.gray)
                    .padding()
            } else {
                List(filteredObservations) { obs in
                    VStack(alignment: .leading) {
                        Text("\(obs.name) – \(obs.studentClass)")
                            .bold()
                        Text(obs.behaviour)
                        Text(obs.note)
                            .font(.subheadline)
                            .foregroundColor(.gray)
                        Text(obs.date.formatted())
                            .font(.caption)
                    }
                }
            }

            #if canImport(MessageUI) && !targetEnvironment(macCatalyst)
            Group {
                Button("📤 Export to Email / PDF") {
                    if let pdf = createPDF(from: filteredObservations) {
                        pdfToShare = pdf
                        showingMailView = true
                    }
                }
                .buttonStyle(.borderedProminent)
                .padding()
                .sheet(isPresented: $showingMailView) {
                    if let data = pdfToShare {
                        MailView(pdfData: data)
                    }
                }
            }
            #else
            Text("PDF export available only on iOS.")
                .foregroundColor(.gray)
                .padding()
            #endif
        }
        .navigationTitle("Filter Records")
    }
}