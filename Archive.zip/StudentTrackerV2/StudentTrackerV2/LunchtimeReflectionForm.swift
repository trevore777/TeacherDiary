
import SwiftUI

struct LunchtimeReflectionForm: View {
    @State private var studentName = ""
    @State private var studentEmail = ""
    @State private var selectedReasons: Set<String> = []
    @State private var comments = ""
    @State private var date = Date()

    let reasonOptions = ["Did not eat", "Disruptive", "No hat", "Fighting", "Other"]

    var body: some View {
        Form {
            Section(header: Text("Student Info")) {
                TextField("Name", text: $studentName)
                TextField("Email", text: $studentEmail)
            }

            Section(header: Text("Reasons")) {
                ForEach(reasonOptions, id: \.self) { reason in
                    MultipleSelectionRow(title: reason, isSelected: selectedReasons.contains(reason)) {
                        if selectedReasons.contains(reason) {
                            selectedReasons.remove(reason)
                        } else {
                            selectedReasons.insert(reason)
                        }
                    }
                }
            }

            Section(header: Text("Additional Comments")) {
                TextEditor(text: $comments)
                    .frame(height: 100)
            }

            Button("Save Reflection") {
                let reflection = LunchtimeReflection(
                    studentName: studentName,
                    studentEmail: studentEmail,
                    date: date,
                    reasons: Array(selectedReasons),
                    comments: comments
                )
                saveLunchtimeReflection(reflection)
            }
        }
        .navigationTitle("New Lunchtime Reflection")
    }
}

struct MultipleSelectionRow: View {
    var title: String
    var isSelected: Bool
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack {
                Text(title)
                if isSelected {
                    Spacer()
                    Image(systemName: "checkmark")
                }
            }
        }
    }
}
