//
//  TASSResponse.swift
//  StudentTrackerV2
//
//  Created by Trevor Elliott on 1/8/2025.
//


struct TASSResponse: Codable {
    let students: [Student]
}

struct Student: Codable {
    let generalDetails: GeneralDetails

    enum CodingKeys: String, CodingKey {
        case generalDetails = "general_details"
    }
}

struct GeneralDetails: Codable {
    let firstName: String
    let surname: String

    enum CodingKeys: String, CodingKey {
        case firstName = "first_name"
        case surname
    }
}
