import SwiftUI
import Combine

class StudentViewModel: ObservableObject {
    @Published var previousNames: [String] = []

    func fetchStudents() {
        guard let url = URL(string: "https://tassweb.kingscollege.qld.edu.au/tassweb/api/?method=getStudentsDetails&appcode=KCC01&company=01&v=3&token=98I8YrpxSpX6rg79sGllfANYaTzrixC36R94PhAFRXA%3d") else {
            print("Invalid URL")
            return
        }

        URLSession.shared.dataTask(with: url) { data, _, error in
            if let data = data {
                do {
                    let decoded = try JSONDecoder().decode(TASSResponse.self, from: data)
                    DispatchQueue.main.async {
                        self.previousNames = decoded.students.map { "\($0.generalDetails.firstName) \($0.generalDetails.surname)" }
                    }
                } catch {
                    print("Decoding error: \(error)")
                }
            } else if let error = error {
                print("Fetch error: \(error)")
            }
        }.resume()
    }
}
