import SwiftUI

struct LoginView: View {
    @State private var username = ""
    @State private var password = ""
    @State private var isLoggedIn = false

    var body: some View {
        if isLoggedIn {
            MainMenuView()
        } else {
            VStack {
                TextField("Enter username", text: $username)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                SecureField("Enter password", text: $password)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()

                Button("Login") {
                    saveLoginDate()
                    isLoggedIn = true
                }
                .buttonStyle(.borderedProminent)
            }
            .padding()
        }
    }

    func saveLoginDate() {
        let now = Date()
        UserDefaults.standard.set(now, forKey: "lastLoginDate")
    }
}