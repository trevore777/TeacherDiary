import Foundation

struct StudentObservation: Identifiable, Codable {
    let id: UUID
    let name: String
    let studentClass: String
    let behaviour: String
    let note: String
    let date: Date

    init(id: UUID = UUID(), name: String, studentClass: String, behaviour: String, note: String, date: Date) {
        self.id = id
        self.name = name
        self.studentClass = studentClass
        self.behaviour = behaviour
        self.note = note
        self.date = date
    }
}

func saveObservations(_ observations: [StudentObservation]) {
    if let encoded = try? JSONEncoder().encode(observations) {
        UserDefaults.standard.set(encoded, forKey: "studentObservations")
        print("💾 Saved \(observations.count) records")
    }
}

func loadObservations() -> [StudentObservation] {
    if let data = UserDefaults.standard.data(forKey: "studentObservations"),
       let decoded = try? JSONDecoder().decode([StudentObservation].self, from: data) {
        print("✅ Loaded \(decoded.count) observations")
        return decoded
    }
    print("⚠️ No observations loaded")
    return []
}