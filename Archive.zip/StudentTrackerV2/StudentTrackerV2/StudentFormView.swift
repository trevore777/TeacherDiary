//
//  StudentFormView.swift
//  StudentTrackerV2
//
//  Created by Trevor Elliott on 1/8/2025.
//
import SwiftUI
import Combine

struct StudentFormView: View {
    @State private var name: String = ""
    @ObservedObject private var viewModel = StudentViewModel()

    var body: some View {
        Form {
            Section(header: Text("New Observation")) {
                VStack(alignment: .leading) {
                    Text("Name")
                    TextField("Enter or select name", text: $name)
                        .textFieldStyle(RoundedBorderTextFieldStyle())

                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack {
                            ForEach(viewModel.previousNames, id: \.self) { item in
                                Button(action: { name = item }) {
                                    Text(item)
                                        .padding(.horizontal, 10)
                                        .padding(.vertical, 5)
                                        .background(Color.gray.opacity(0.2))
                                        .cornerRadius(10)
                                }
                            }
                        }
                        .frame(minHeight: 40)
                    }
                }
            }
        }
        .onAppear {
            viewModel.fetchStudents()
        }
    }
}
