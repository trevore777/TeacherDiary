
import Foundation
import PDFKit
import UIKit

func saveLunchtimeReflection(_ reflection: LunchtimeReflection) {
    var reflections = loadLunchtimeReflections()
    reflections.append(reflection)
    if let encoded = try? JSONEncoder().encode(reflections) {
        UserDefaults.standard.set(encoded, forKey: "lunchtimeReflections")
    }
}

func loadLunchtimeReflections() -> [LunchtimeReflection] {
    if let data = UserDefaults.standard.data(forKey: "lunchtimeReflections"),
       let decoded = try? JSONDecoder().decode([LunchtimeReflection].self, from: data) {
        return decoded
    }
    return []
}

func createLunchtimePDF(from reflections: [LunchtimeReflection]) -> Data? {
    let format = UIGraphicsPDFRendererFormat()
    let pageRect = CGRect(x: 0, y: 0, width: 595.2, height: 841.8)
    let renderer = UIGraphicsPDFRenderer(bounds: pageRect, format: format)

    let data = renderer.pdfData { context in
        context.beginPage()
        var y: CGFloat = 20

        for reflection in reflections {
            let lines = [
                "Name: \(reflection.studentName)",
                "Email: \(reflection.studentEmail)",
                "Date: \(reflection.date.formatted())",
                "Reasons: \(reflection.reasons.joined(separator: ", "))",
                "Comments: \(reflection.comments)"
            ]

            for line in lines {
                let attributes: [NSAttributedString.Key: Any] = [
                    .font: UIFont.systemFont(ofSize: 12)
                ]
                let drawRect = CGRect(x: 20, y: y, width: pageRect.width - 40, height: 20)
                line.draw(in: drawRect, withAttributes: attributes)
                y += 20
            }

            y += 20
            if y > pageRect.height - 40 {
                context.beginPage()
                y = 20
            }
        }
    }

    return data
}
