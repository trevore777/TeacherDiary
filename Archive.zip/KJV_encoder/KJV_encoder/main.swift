import Foundation

// 👉 Set your paths here
let inputDirectory = URL(fileURLWithPath: "/PATH/TO/en_kjv")  // folder with 66 per-book JSON files
let outputFile     = URL(fileURLWithPath: "/PATH/TO/kjv.json") // final merged file

do {
    print("📖 Reading \(inputDirectory.path)")
    let src = try loadSourceBooks(from: inputDirectory)
    let ordered = sortBooksCanonically(src)
    let outBooks = ordered.map(convert)
    let kjv = KJVData(books: outBooks)

    let enc = JSONEncoder()
    enc.outputFormatting = [.prettyPrinted, .sortedKeys]
    let data = try enc.encode(kjv)
    try data.write(to: outputFile, options: [.atomic])

    print("✅ Wrote \(outputFile.path)")
} catch {
    fputs("❌ \(error)\n", stderr)
    exit(EXIT_FAILURE)
}
