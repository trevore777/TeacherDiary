import Foundation

func loadSourceBooks(from folder: URL) throws -> [SourceBook] {
    let fm = FileManager.default
    let files = try fm.contentsOfDirectory(at: folder, includingPropertiesForKeys: nil, options: [.skipsHiddenFiles])
        .filter { $0.pathExtension.lowercased() == "json" }

    var out: [SourceBook] = []
    for url in files {
        do {
            let data = try Data(contentsOf: url)
            let book = try JSONDecoder().decode(SourceBook.self, from: data)
            out.append(book)
            print("✅ Loaded \(book.book)")
        } catch {
            print("⚠️ Skipped \(url.lastPathComponent): \(error)")
        }
    }
    return out
}

func convert(_ s: SourceBook) -> KJVBookOut {
    let chapterPairs = s.chapters.compactMap { (k, v) -> (Int, [String])? in
        guard let n = Int(k) else { return nil }
        return (n, v)
    }.sorted { $0.0 < $1.0 }

    let chapters = chapterPairs.map { (num, verses) in
        let outVerses = verses.enumerated().map { (i, t) in
            KJVVerseOut(verseNumber: i + 1, text: t.trimmingCharacters(in: .whitespacesAndNewlines))
        }
        return KJVChapterOut(chapterNumber: num, verses: outVerses)
    }
    return KJVBookOut(name: s.book, chapters: chapters)
}

let bibleOrder = [
    "Genesis","Exodus","Leviticus","Numbers","Deuteronomy",
    "Joshua","Judges","Ruth","1 Samuel","2 Samuel","1 Kings","2 Kings","1 Chronicles","2 Chronicles",
    "Ezra","Nehemiah","Esther","Job","Psalms","Proverbs","Ecclesiastes","Song of Solomon",
    "Isaiah","Jeremiah","Lamentations","Ezekiel","Daniel",
    "Hosea","Joel","Amos","Obadiah","Jonah","Micah","Nahum","Habakkuk","Zephaniah","Haggai","Zechariah","Malachi",
    "Matthew","Mark","Luke","John","Acts",
    "Romans","1 Corinthians","2 Corinthians","Galatians","Ephesians","Philippians","Colossians",
    "1 Thessalonians","2 Thessalonians","1 Timothy","2 Timothy","Titus","Philemon",
    "Hebrews","James","1 Peter","2 Peter","1 John","2 John","3 John","Jude","Revelation"
]

func sortBooksCanonically(_ books: [SourceBook]) -> [SourceBook] {
    let index = Dictionary(uniqueKeysWithValues: bibleOrder.enumerated().map { ($1, $0) })
    return books.sorted { (index[$0.book] ?? 999) < (index[$1.book] ?? 999) }
}
