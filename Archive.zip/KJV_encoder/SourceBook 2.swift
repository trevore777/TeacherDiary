//
//  SourceBook 2.swift
//  KJV_encoder
//
//  Created by Trevor Elliott on 30/10/2025.
//


import Foundation

// Source repo book file
struct SourceBook: Decodable {
    let book: String
    let chapters: [String: [String]]
}

// Final kjv.json types
struct KJVData: Encodable { let books: [KJVBookOut] }
struct KJVBookOut: Encodable { let name: String; let chapters: [KJVChapterOut] }
struct KJVChapterOut: Encodable { let chapterNumber: Int; let verses: [KJVVerseOut] }
struct KJVVerseOut: Encodable { let verseNumber: Int; let text: String }
