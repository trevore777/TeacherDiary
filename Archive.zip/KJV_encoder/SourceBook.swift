import Foundation

struct SourceBook: Decodable { let book: String; let chapters: [String: [String]] }
struct KJVData: Encodable { let books: [KJVBookOut] }
struct KJVBookOut: Encodable { let name: String; let chapters: [KJVChapterOut] }
struct KJVChapterOut: Encodable { let chapterNumber: Int; let verses: [KJVVerseOut] }
struct KJVVerseOut: Encodable { let verseNumber: Int; let text: String }

@main
struct KJVEncoder {
    static func main() {
        // set paths
        let inputDirectory = URL(fileURLWithPath: "/PATH/TO/en_kjv")
        let outputFile = URL(fileURLWithPath: "/PATH/TO/kjv.json")

        do {
            let src = try loadSourceBooks(from: inputDirectory)
            let ordered = sortBooksCanonically(src)
            let out = KJVData(books: ordered.map(convert))
            let enc = JSONEncoder()
            enc.outputFormatting = [.prettyPrinted, .sortedKeys]
            try enc.encode(out).write(to: outputFile, options: [.atomic])
            print("✅ Wrote \(outputFile.path)")
        } catch {
            print("❌ \(error)")
            exit(EXIT_FAILURE)
        }
    }

    // helpers (same as before, pasted inside the struct)
    static func loadSourceBooks(from folder: URL) throws -> [SourceBook] { /* ... paste ... */ }
    static func convert(_ s: SourceBook) -> KJVBookOut { /* ... paste ... */ }
    static func sortBooksCanonically(_ books: [SourceBook]) -> [SourceBook] { /* ... paste ... */ }
}
