
import SwiftUI

struct BlueSlipView: View {
    @State private var name = ""
    @State private var yearLevel = ""
    @State private var reason = ""
    @State private var otherReason = ""
    @State private var rtcReturnOption = "N"
    @State private var memo = ""
    @State private var date = Date()
    @State private var timeSent = ""
    @State private var timeReturned = ""

    @Environment(\.presentationMode) var presentationMode

    let yearLevels = ["7", "8", "9", "10", "11", "12"]
    let reasons = ["BATHROOM", "BUBBLERS", "CLINIC", "IT HELP DESK", "LIBRARY", "LOCKERS", "OFFICE", "RTC", "STDNT SVCS", "OTHER"]

    var body: some View {
        Form {
            Section(header: Text("Student Info")) {
                TextField("Name", text: $name)
                Picker("Year Level", selection: $yearLevel) {
                    ForEach(yearLevels, id: \.self) { year in
                        Text(year)
                    }
                }
            }

            Section(header: Text("Reason")) {
                Picker("Reason", selection: $reason) {
                    ForEach(reasons, id: \.self) { r in
                        Text(r)
                    }
                }
                if reason == "OTHER" {
                    TextField("Other Reason", text: $otherReason)
                }
                if reason == "RTC" {
                    Picker("RTC Return?", selection: $rtcReturnOption) {
                        Text("Yes").tag("Y")
                        Text("No").tag("N")
                    }
                    .pickerStyle(SegmentedPickerStyle())
                }
            }

            Section(header: Text("Date and Time")) {
                DatePicker("Date", selection: $date, displayedComponents: .date)
                TextField("Time Sent", text: $timeSent)
                TextField("Time Returned", text: $timeReturned)
            }

            Section(header: Text("Memo")) {
                TextEditor(text: $memo)
                    .frame(height: 100)
            }

            Button("Save") {
                let slip = BlueSlip(
                    name: name,
                    yearLevel: yearLevel,
                    reason: reason,
                    otherReason: otherReason.isEmpty ? nil : otherReason,
                    rtcReturnOption: rtcReturnOption,
                    date: memo,
                    timeSent: date,
                    timeReturned: timeSent,
                    memo: timeReturned
                )
                saveBlueSlip(slip)
                presentationMode.wrappedValue.dismiss()
            }
        }
        .navigationTitle("New Blue Slip")
    }
}
