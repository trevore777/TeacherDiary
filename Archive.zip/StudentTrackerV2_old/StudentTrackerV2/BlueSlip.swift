import Foundation

struct BlueSlip: Identifiable, Codable {
    let id = UUID()
    let name: String
    let yearLevel: String
    let reason: String
    let otherReason: String?
    let rtcReturnOption: String? // Y or N
    let date: Date
    let timeSent: String
    let timeReturned: String
    let memo: String?
}