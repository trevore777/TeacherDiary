//
//  BackgroundView.swift
//  StudentTrackerV2
//
//  Created by Trevor Elliott on 28/7/2025.
//

import SwiftUI

struct BackgroundView<Content: View>: View {
    let content: Content

    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }

    var body: some View {
        ZStack {
            Image("backgroundImage")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()
            content
        }
    }
}
