import SwiftUI
import UniformTypeIdentifiers

struct BlueSlipListView: View {
    @State private var slips: [BlueSlip] = loadBlueSlips()
    @State private var filterName = ""
    @State private var filterDate = Date()
    @State private var showingMail = false
    @State private var pdfData: Data?

    var body: some View {
        VStack {
            Form {
                Section(header: Text("Filter")) {
                    TextField("Student Name", text: $filterName)
                    DatePicker("Date", selection: $filterDate, displayedComponents: .date)
                    Button("Apply Filter") {
                        slips = loadBlueSlips().filter {
                            $0.name.lowercased().contains(filterName.lowercased()) &&
                            Calendar.current.isDate($0.date, inSameDayAs: filterDate)
                        }
                    }
                }
            }

            List(slips) { slip in
                VStack(alignment: .leading) {
                    Text("\(slip.name) (Yr \(slip.yearLevel))").bold()
                    Text("Reason: \(slip.reason)")
                    if let other = slip.otherReason {
                        Text("Other: \(other)")
                    }
                    if slip.reason == "RTC" {
                        Text("RTC Return: \(slip.rtcReturnOption ?? "-")")
                    }
                    Text("Time: \(slip.timeSent) - \(slip.timeReturned)")
                    Text("Date: \(slip.date.formatted())")
                    if let memo = slip.memo {
                        Text("Memo: \(memo)")
                    }
                }
                .padding(.vertical, 4)
            }

            Button("Export to PDF & Email") {
                pdfData = createBlueSlipPDF(from: slips)
                showingMail = true
            }
            .disabled(slips.isEmpty)
            .padding()
        }
        .navigationTitle("View Blue Slips")
        .sheet(isPresented: $showingMail) {
            if let pdf = pdfData {
                ShareSheet(activityItems: [pdf])
            }
        }
    }
}