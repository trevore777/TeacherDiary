import UIKit
import PDFKit

func createBlueSlipPDF(from slips: [BlueSlip]) -> Data? {
    let pageWidth: CGFloat = 595.2
    let pageHeight: CGFloat = 841.8
    let margin: CGFloat = 20
    let lineHeight: CGFloat = 20

    let pageRect = CGRect(x: 0, y: 0, width: pageWidth, height: pageHeight)
    let format = UIGraphicsPDFRendererFormat()
    let renderer = UIGraphicsPDFRenderer(bounds: pageRect, format: format)

    let data = renderer.pdfData { context in
        context.beginPage()
        var y = margin

        for slip in slips {
            let lines = [
                "Name: \(slip.name)",
                "Year Level: \(slip.yearLevel)",
                "Reason: \(slip.reason)",
                "Other: \(slip.otherReason ?? "-")",
                "RTC Return: \(slip.rtcReturnOption ?? "-")",
                "Staff: \(slip.staff)",
                "Date: \(slip.date.formatted())",
                "Time: \(slip.timeSent) - \(slip.timeReturned)",
                "Signature: \(slip.staffSignature)"
            ]

            for line in lines {
                let attrs: [NSAttributedString.Key: Any] = [
                    .font: UIFont.systemFont(ofSize: 12)
                ]
                let drawRect = CGRect(x: margin, y: y, width: pageWidth - 2 * margin, height: lineHeight)
                line.draw(in: drawRect, withAttributes: attrs)
                y += lineHeight

                if y + lineHeight > pageHeight - margin {
                    context.beginPage()
                    y = margin
                }
            }

            y += lineHeight
        }
    }

    return data
}