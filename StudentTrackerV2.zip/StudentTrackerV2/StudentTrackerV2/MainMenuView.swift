import SwiftUI

struct MainMenuView: View {
    var body: some View {
        NavigationView {
            List {
                NavigationLink(destination: StudentObservationView()) {
                    Text("New Student Observation")
                }
                NavigationLink(destination: RecordFilterView()) {
                    Text("View Observations")
                }
                NavigationLink(destination: BlueSlipView()) {
                    Text("New Blue Slip")
                }
                NavigationLink(destination: BlueSlipListView()) {
                    Text("View Blue Slips")
                }
            }
            .navigationTitle("Main Menu")
        }
    }
}