import Foundation

struct StudentObservation2: Identifiable, Codable {
    let id: UUID
    let name: String
    let studentClass: String
    let behaviour: String
    let note: String
    let date: Date
}

func saveObservations2(_ observations: [StudentObservation]) {
    if let encoded = try? JSONEncoder().encode(observations) {
        UserDefaults.standard.set(encoded, forKey: "studentObservations")
    }
}

func loadObservations2() -> [StudentObservation] {
    if let data = UserDefaults.standard.data(forKey: "studentObservations"),
       let decoded = try? JSONDecoder().decode([StudentObservation].self, from: data) {
        return decoded
    }
    return []
}
