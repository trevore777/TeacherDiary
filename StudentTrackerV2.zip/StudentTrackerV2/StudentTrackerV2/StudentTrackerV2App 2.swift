import SwiftUI

@main
struct StudentTrackerV2App: App {
    var body: some Scene {
        WindowGroup {
            SplashScreen()
        }
    }
}