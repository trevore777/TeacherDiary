import SwiftUI

struct RecordMenuView: View {
    var body: some View {
        NavigationView {
            List {
                NavigationLink("➕ Add New Record", destination: StudentObservationView())
                NavigationLink("🔍 View Records", destination: RecordFilterView())
            }
            .navigationTitle("Records Menu")
        }
    }
}