import Foundation

func saveBlueSlip(_ slip: BlueSlip) {
    var slips = loadBlueSlips()
    slips.append(slip)
    if let encoded = try? JSONEncoder().encode(slips) {
        UserDefaults.standard.set(encoded, forKey: "blueSlips")
    }
}

func loadBlueSlips() -> [BlueSlip] {
    if let data = UserDefaults.standard.data(forKey: "blueSlips"),
       let decoded = try? JSONDecoder().decode([BlueSlip].self, from: data) {
        return decoded
    }
    return []
}