import SwiftUI

struct StudentObservationView: View {
    @State private var name = ""
    @State private var studentClass = ""
    @State private var behaviour = ""
    @State private var note = ""
    @State private var observations: [StudentObservation] = []

    var previousNames: [String] {
        Array(Set(observations.map { $0.name })).sorted()
    }

    var previousClasses: [String] {
        Array(Set(observations.map { $0.studentClass })).sorted()
    }

    var previousBehaviours: [String] {
        Array(Set(observations.map { $0.behaviour })).sorted()
    }

    var body: some View {
        Form {
            Section(header: Text("New Observation")) {
                VStack(alignment: .leading) {
                    Text("Name")
                    TextField("Enter or select name", text: $name)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack {
                            ForEach(previousNames, id: \.self) { item in
                                Button(action: { name = item }) {
                                    Text(item)
                                        .padding(.horizontal, 10)
                                        .padding(.vertical, 5)
                                        .background(Color.gray.opacity(0.2))
                                        .cornerRadius(10)
                                }
                            }
                        }
                        .frame(minHeight: 40)
                    }
                }

                VStack(alignment: .leading) {
                    Text("Class")
                    TextField("Enter or select class", text: $studentClass)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack {
                            ForEach(previousClasses, id: \.self) { item in
                                Button(action: { studentClass = item }) {
                                    Text(item)
                                        .padding(.horizontal, 10)
                                        .padding(.vertical, 5)
                                        .background(Color.gray.opacity(0.2))
                                        .cornerRadius(10)
                                }
                            }
                        }
                        .frame(minHeight: 40)
                    }
                }

                VStack(alignment: .leading) {
                    Text("Behaviour")
                    TextField("Enter or select behaviour", text: $behaviour)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack {
                            ForEach(previousBehaviours, id: \.self) { item in
                                Button(action: { behaviour = item }) {
                                    Text(item)
                                        .padding(.horizontal, 10)
                                        .padding(.vertical, 5)
                                        .background(Color.gray.opacity(0.2))
                                        .cornerRadius(10)
                                }
                            }
                        }
                        .frame(minHeight: 40)
                    }
                }

                TextField("Note", text: $note)

                Button("Save") {
                    let new = StudentObservation(
                        name: name,
                        studentClass: studentClass,
                        behaviour: behaviour,
                        note: note,
                        date: Date()
                    )
                    observations.append(new)
                    saveObservations(observations)
                    name = ""
                    studentClass = ""
                    behaviour = ""
                    note = ""
                }
            }

            Section(header: Text("Recent Observations")) {
                ForEach(observations.suffix(5).reversed()) { obs in
                    VStack(alignment: .leading) {
                        Text("\(obs.name) – \(obs.studentClass)")
                            .bold()
                        Text(obs.behaviour)
                        Text(obs.note)
                            .font(.subheadline)
                            .foregroundColor(.gray)
                        Text(obs.date.formatted())
                            .font(.caption)
                    }
                    .padding(.vertical, 4)
                }
            }
        }
        .navigationTitle("Student Observation")
        .onAppear {
            observations = loadObservations()
        }
    }
}